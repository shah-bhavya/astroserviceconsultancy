﻿<!DOCTYPE html>
<html lang="en">
<!--<![endif]-->
<!-- Begin Head -->
<!-- Mirrored from kamleshyadav.com/html/astrology/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Aug 2018 06:22:18 GMT -->
<head>
    <title>Astrology Service Consultancy</title>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="Astrology">
    <meta name="keywords" content="Astrology, signs, gemstones, tarot, horoscopes, cards, numerology, Zodiac">
    <meta name="author" content="hsoft">
    <meta name="MobileOptimized" content="320">
    <!--Srart Style -->
    <link rel="stylesheet" type="text/css" href="Default/css/animate.css">
    <link rel="stylesheet" type="text/css" href="Default/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="Default/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="Default/css/fonts.css">
    <link rel="stylesheet" type="text/css" href="Default/css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="Default/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="Default/css/magnific-popup.css">
    <link rel="stylesheet" type="text/css" href="Default/css/style.css">
    <!-- Favicon Link -->
    <link rel="shortcut icon" type="image/png" href="Default/images/header/favicon.png">
    <style>
        h2 {
            color: #f7b70b !important;
        }

        span {
            color: #f7b70b;
        }

        .ast_btn {
            background-color: #f7b70b !important;
            border: 1px solid #f7b70b !important;
        }

            .ast_btn:hover {
                background-color: transparent !important;
                color: #f7b70b !important;
            }

        .ast_whywe_info_box span {
            background-color: #f7b70b !important;
        }

        .ast_menu ul li a.active {
            /*background-color: #ff6f00;*/
            color: #f7b70b !important;
        }

        .ast_contact_info:hover span {
            background-color: #f7b70b !important;
        }

        .ast_contact_info span i {
            color: #f7b70b;
        }

        .ast_contact_info:hover span:hover {
            color: #fff !important;
        }

        .ast_service_box:hover h4 {
            color: #f7b70b !important;
        }

        .ast_service_box:hover .transform {
            transition: all 1.5s;
            transform: rotate(360deg) !important;
        }

        .owl-next:hover {
            background-color: #f7b70b !important;
        }

        .owl-prev:hover {
            background-color: #f7b70b !important;
        }

        .ml16 {
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.2em;
        }

            .ml16 .word {
                display: inline-block;
                line-height: 1em;
            }

        @media (max-width: 991px) {
            .ast_menu_btn {
                background-color: #f7b70b !important;
            }
        }

        .ast_service_box:hover img {
            display: inline-block !important;
            background-color: #f4c84f94 !important;
        }

        .box-shadow {
            box-shadow: #bcb5b5 2px 2px 2px 2px;
        }

        .fix-height-width {
            height: 240px;
            width: 360px;
        }

        .ast_blog_img .ast_date_tag {
            background-color: #f7b70b;
            width: 70px;
            text-align: center;
            padding: 12px 0px;
        }

        .bold {
            font-weight: 600;
        }

        .ast_blog_info ul.ast_blog_info_text li a i {
            color: #f7b70b;
        }

        .ast_blog_info ul.ast_blog_info_text li a:hover {
            color: #f7b70b;
        }

        i .color {
            color: #f7b70b !important;
        }

        .ast_header_bottom {
            margin-top: 0px;
        }

        /*Bounceicon*/
        .bounce {
            display: inline-block;
            position: relative;
            -moz-animation: bounce 0.5s infinite linear;
            -o-animation: bounce 0.5s infinite linear;
            -webkit-animation: bounce 0.5s infinite linear;
            animation: bounce 0.5s infinite linear;
            colr: 000;
        }

        .fa-whatsapp {
            color: white;
            font-size: 20px;
        }

        @-webkit-keyframes bounce {
            0% {
                top: 0;
            }

            50% {
                top: -0.2em;
            }

            70% {
                top: -0.3em;
            }

            100% {
                top: 0;
            }
        }

        @-moz-keyframes bounce {
            0% {
                top: 0;
            }

            50% {
                top: -0.2em;
            }

            70% {
                top: -0.3em;
            }

            100% {
                top: 0;
            }
        }

        @-o-keyframes bounce {
            0% {
                top: 0;
            }

            50% {
                top: -0.2em;
            }

            70% {
                top: -0.3em;
            }

            100% {
                top: 0;
            }
        }

        @-ms-keyframes bounce {
            0% {
                top: 0;
            }

            50% {
                top: -0.2em;
            }

            70% {
                top: -0.3em;
            }

            100% {
                top: 0;
            }
        }

        @keyframes bounce {
            0% {
                top: 0;
            }

            50% {
                top: -0.2em;
            }

            70% {
                top: -0.3em;
            }

            100% {
                top: 0;
            }
        }

        .ast_contact_map {
            padding-top: 775px !important;
        }

        .ast_service_box img {
            border-radius: 20% !important;
        }

        .ast_contact_form {
            top: -782px !important;
        }

        .ast_contact_form_custom {
            width: 90%;
            background-color: #ffffff;
            padding: 50px 20px 520px 20px !important;
            margin: 0px auto;
            border-radius: 3px;
            -webkit-box-shadow: 0px 0px 30px -10px #000000;
            -moz-box-shadow: 0px 0px 30px -10px #000000;
            -o-box-shadow: 0px 0px 30px -10px #000000;
            -ms-box-shadow: 0px 0px 30px -10px #000000;
            box-shadow: 0px 0px 30px -10px #000000;
        }

            .ast_contact_form_custom label {
                float: left;
                width: 100%;
                text-transform: capitalize;
                color: #333333;
                font-weight: 600;
                border-radius: 3px;
            }

            .ast_contact_form_custom input, .ast_contact_form_custom textarea {
                float: left;
                width: 100%;
                height: 45px;
                padding: 0px 15px;
                border: 1px solid #e1e1e1;
                margin-bottom: 15px;
            }

            .ast_contact_form_custom textarea {
                height: auto;
                padding: 10px 15px;
                resize: vertical;
            }

        .ast_copyright_wrapper_custom {
            border-top: 1px dotted #ffffff;
            padding-top: 20px;
        }

            .ast_copyright_wrapper_custom h4 {
                margin-bottom: 0px;
                text-transform: capitalize;
                color: #ffffff;
            }

                .ast_copyright_wrapper_custom h4 a {
                    font-weight: 700;
                    color: #f7b70b;
                }

        .ast_service_box {
            border-radius: 10% !important;
        }

        .ast_timer_wrapper {
            background-image: url('Default/images/content/timer_bg.jpg') !important;
        }

        @media(max-width:500px) {
            .ast_slider_wrapper {
                float: left;
                width: 100%;
                position: relative;
                background-color: #111111;
                z-index: 1;
                background-image: url('Default/images/moon_glow_dark_space_mobile.jpg');
                background-position: center center;
                background-repeat: no-repeat;
                background-attachment: fixed;
            }
        }

        .ml12 {
            font-weight: 600;
            font-size: 1.8em;
            text-transform: uppercase;
            letter-spacing: 0.5em;
        }

            .ml12 .letter {
                display: inline-block;
                line-height: 1em;
                color:white!important;
            }
            .ml12 span .letter
            {
                color:white!important;
            }
    </style>

</head>
<body>
    <!-- Header Start -->
    <!--<div class="ast_top_header" id="Home" style="background-image: linear-gradient(to right, #f7db9f , #f7b70b);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="ast_contact_details">
                        <ul>
                            <li><i class="color fa fa-phone" aria-hidden="true"></i> +1800 326 3264</li>
                            <li><a href="Default/#"><i class="fa fa-envelope-o" aria-hidden="true"></i> support@website.com</a></li>
                        </ul>
                    </div>
                    <div class="ast_autho_wrapper">
                        <ul>
                            <li><a class="popup-with-zoom-anim" href="Default/#login-dialog"><i class="fa fa-sign-in" aria-hidden="true"></i> Log In</a></li>
                            <li><a class="popup-with-zoom-anim" href="Default/#signup-dialog"><i class="fa fa-user-plus" aria-hidden="true"></i> Sign Up</a></li>
                            <li class="ast_search">
                                <a href="Default/javascript:;"><i class="fa fa-search"></i></a>
                                <div class="ast_search_field">
                                    <form>
                                        <input type="text" placeholder="Search Here">
                                        <button type="button"><i class="fa fa-search"></i></button>
                                    </form>
                                </div>
                            </li>

                        </ul>
                        <div id="login-dialog" class="zoom-anim-dialog mfp-hide">
                            <h1>Login Form</h1>
                            <form>
                                <input type="text" placeholder="Email">
                                <input type="password" placeholder="Password">
                                <div class="ast_login_data">
                                    <label class="tp_custom_check" for="remember_me">
                                        Remember me <input type="checkbox" name="ast_remember_me" value="yes" id="ast_remember_me"><span class="checkmark"></span>
                                    </label>
                                    <a href="Default/#">Forgot password ?</a>
                                </div>
                                <button type="submit" class="ast_btn">Login</button>
                                <p>Create An Account ? <a href="Default/#">SignUp</a></p>
                            </form>
                        </div>
                        <div id="signup-dialog" class="zoom-anim-dialog mfp-hide">
                            <h1>signup form</h1>
                            <form>
                                <input type="text" placeholder="Name">
                                <input type="text" placeholder="Email">
                                <input type="password" placeholder="Password">
                                <input type="text" placeholder="Mobile Number">
                                <select>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                                <button type="submit" class="ast_btn">submit</button>
                                <p>Have An Account ? <a href="Default/#">Login</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>-->
    <div id="Home">
        <div class="ast_header_bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="ast_logo">
                            <a href="index.html"><img src="Default/images/header/logo.png" alt="Logo" title="Logo"></a>
                            <button class="ast_menu_btn"><i class="fa fa-bars" aria-hidden="true"></i></button>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                        <div class="ast_main_menu_wrapper">
                            <div class="ast_menu navigation">
                                <ul>
                                    <li>
                                        <a class="active" href="#Home">HOME</a>
                                        <!--<ul class="submenu">
                                            <li><a href="Default/index.html">home</a></li>

                                        </ul>-->
                                    </li>
                                    <li><a href="#AboutUs">ABOUT</a></li>
                                    <li><a href="#Services">SERVICES</a></li>
                                    <li><a href="#works">WORKS</a></li>
                                    <li><a href="#ContactUs">CONTACT</a></li>
                                    <li><a href="tel:7434804490"><i class="fa fa-phone"></i>&nbsp;&nbsp;7434804490</a></li>
                                    <li>
                                        <!--<a href="https://api.whatsapp.com/send?phone=+917434804490&text=testing"><i class="fa fa-whatsapp bounce"></i></a>-->
                                        <a href="whatsapp://send?text=Hello , I am Deepak How can i help you !!" data-action="share/whatsapp/share"><i class="fa fa-whatsapp bounce"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->
    <!--Slider Start-->
    <div class="ast_slider_wrapper">
        <div class="ast_banner_text">
            <div class="starfield">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="ast_waves">
                <div class="ast_wave"></div>
                <div class="ast_wave"></div>
                <div class="ast_wave"></div>
            </div>
            <div class="ast_waves2">
                <div class="ast_wave"></div>
                <div class="ast_wave"></div>
                <div class="ast_wave"></div>
            </div>
            <div class="ast_waves3">
                <div class="ast_wave"></div>
                <div class="ast_wave"></div>
                <div class="ast_wave"></div>
            </div>
            <div class="container">
                <div class="ast_bannertext_wrapper">
                    <h2 class="ml16 ">
                        <span class="word">The </span>
                        <span class="word">Astrology</span>
                        <span class="word">Service </span>
                        <span class="word">Consultancy</span>
                    </h2>
                    <ul class="ast_toppadder40 ast_bottompadder50">
                        <li class="ml12">
                            <h4 style="color:white;">It is a Blue Print</h4>
                        </li>
                    </ul>
                    <a class="ast_btn" href="#ContactUs"><i class="fa fa-phone"></i> Contact Us</a>
                </div>
            </div>
        </div>
    </div>
    <!--Slider End-->
    <!--About Us Start-->

    <div class="ast_about_wrapper ast_toppadder80 ast_bottompadder70" id="AboutUs">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1 col-xs-offset-0" style="margin-bottom:40px;">
                    <div class="ast_heading">
                        <h1>about <span>astrology</span></h1>
                        <p>Astrology is an ancient art that extends WAY beyond your personal horoscopes. Understanding the patterns of the universe gives you the insight you need to navigate life.</p>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 col-lg-push-7 col-md-push-7 col-sm-push-0 col-xs-push-0">
                    <div class="ast_about_info_img">
                        <div class="about_slider">
                            <div class="card c" id="first"><img src="Default/images/content/hr-abt1.jpg" alt="" class="img-responsive"></div>
                            <div class="card a" id="second"><img src="Default/images/content/hr-abt2.jpg" alt="" class="img-responsive"></div>

                            <div class="btn-wrap">
                                <a href="javascript:void(0);" class="btn focus" id="one"></a>
                                <a href="javascript:void(0);" class="btn" id="two"></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 col-lg-pull-5 col-md-pull-5 col-sm-pull-0 col-xs-pull-0">
                    <div class="ast_about_info">
                        <h4>know about astrology</h4>
                        <p>Astroserviceconsultancy.com is a portal where our clients and audience get better advice and better solution of any types of problems,  with the help of the Best Astrologer in India, get better instant solution of any problems of life by Astroserviceconsultancy.com. Astroserviceconsultancy.com provides you the best Astrology service & instant solution of any problem of life  in India & all over World.</p>
                        <p>We provide the instant solution of any family problem, Love marriage problem & love and business and control mind everyone parson and personnel problems solve immediately by Astroserviceconsultany.com.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--About Us End-->
    <!--WhyWe Us Start-->
    <div class="ast_whywe_wrapper ast_toppadder70 ast_bottompadder70">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1 col-xs-offset-0">
                    <div class="ast_heading">
                        <h1>why  <span>choose us</span></h1>
                        <p>There is no lack of professional astrologers in the India. But searching the best among them is the real deal.</p>
                    </div>
                </div>
                <div class="ast_whywe_info">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="ast_whywe_info_box">
                            <span><img src="Default/images/content/ww_1.png" alt=""></span>
                            <div class="ast_whywe_info_box_info">
                                <p>Expert Astrologers</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="ast_whywe_info_box">
                            <span><img src="Default/images/content/ww_2.png" alt=""></span>
                            <div class="ast_whywe_info_box_info">
                                <p>24x7, 365 Days Availability</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="ast_whywe_info_box">
                            <span><img src="Default/images/content/ww_3.png" alt=""></span>
                            <div class="ast_whywe_info_box_info">
                                <p>Instant Access Worldwide</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="ast_whywe_info_box">
                            <span><img src="Default/images/content/ww_4.png" alt=""></span>
                            <div class="ast_whywe_info_box_info">
                                <p>Accurate Remedial Solutions</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="ast_whywe_info_box">
                            <span><img src="Default/images/content/ww_5.png" alt=""></span>
                            <div class="ast_whywe_info_box_info">
                                <p>Privacy Guaranteed</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="ast_whywe_info_box">
                            <span><img src="Default/images/content/ww_6.png" alt=""></span>
                            <div class="ast_whywe_info_box_info">
                                <p>Trusted by million clients</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--WhyWe Us End-->
    <!--Services Start-->
    <div id="Services" class="ast_service_wrapper ast_toppadder70 ast_bottompadder50">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1 col-xs-offset-0">
                    <div class="ast_heading">
                        <h1>our <span>services</span></h1>
                        <!--<p>There is a famous saying that “life is what happens to you when you are busy making other plans.” What does my future hold? This is one question that every one of us would like to know.</p>-->
                        <img src="Default/images/line.png" />
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="ast_service_slider">
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/success.png" alt="Service" class="transform box-shadow">
                                    <h4>Career Problem Solution</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/planning.png" alt="Service" class="transform box-shadow">
                                    <h4>Kundli Matching Services</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/heartbeat.png" alt="Service" class="transform box-shadow">
                                    <h4>Health Problem</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/justice-hammer.png" alt="Service" class="transform box-shadow">
                                    <h4>Court Case Problem</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/husband-wife-problem.png" alt="Service" class="transform box-shadow">
                                    <h4>Husband Wife Dispute</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/wedding.png" alt="Service" class="transform box-shadow">
                                    <h4>Love Marraige</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/problem.png" alt="Service" class="transform box-shadow">
                                    <h4>Business Problem</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="ast_service_box">
                                    <img src="Default/images/crawling-baby-silhouette.png" alt="Service" class="transform box-shadow">
                                    <h4>Child Problem</h4>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Services End-->
    <!--Timer Section start -->
    <div class="ast_timer_wrapper ast_toppadder70 ast_bottompadder40">
        <div class="ast_img_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1 col-xs-offset-0">
                    <div class="ast_heading">
                        <h1>now <span>we have</span></h1>
                        <img src="Default/images/line_white.png" />
                    </div>
                </div>
                <div class="ast_counter_wrapper">
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="ast_counter">
                            <span><img src="Default/images/users-group.png" alt="timer"></span>
                            <h2 class="timer" data-from="0" data-to="50000" data-speed="3000"></h2>
                            <h4>Satisfied Customers</h4>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="ast_counter">
                            <span><img src="Default/images/24-hours-support.png" alt="timer"></span>
                            <h2 class="timer" data-from="0" data-to="24" data-speed="5000"></h2>
                            <h4>Available</h4>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="ast_counter">
                            <span><img src="Default/images/discount-sticker-with-percentage.png" alt="timer"></span>
                            <h2 class="timer" data-from="0" data-to="100" data-speed="3000"></h2>
                            <h4>Success Ratio</h4>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="ast_counter">
                            <span><img src="Default/images/content/timer_4.png" alt="timer"></span>
                            <h2 class="timer" data-from="0" data-to="30" data-speed="5000"></h2>
                            <h4>Years of Experiences</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Timer Section end -->
    <!--WeDo Start-->
    <div class="ast_blog_wrapper ast_toppadder70 ast_bottompadder70" id="works">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1 col-xs-offset-0" style="margin-bottom:40px;">
                    <div class="ast_heading">
                        <h1>What <span>We Do</span></h1>
                        <p>We provide the instant solution of any family problem, Love marriage problem & love and business and control mind everyone parson and personnel problems solve immediately.</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;">Astrology</span>
                                    <a href="blog_single.html"><img src="Default/images/Astrology.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Astrology</a></li>
                                    </ul>
                                    <!--<h4 class="ast_blog_info_heading"><a href="blog_single.html">Rahu Enters Cancer and Ketu Enters Capricorn.</a></h4>-->
                                    <p class="ast_blog_info_details">Astroserviceconsultancy.com is a portal where our clients and audience get better advice and better solution of any types of problems,  with the help of the Best Astrologer in India, get better instant solution of any problems of life.</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;">Love Marriage</span>
                                    <a><img src="Default/images/Love Marriage.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Love Marriage</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details">Over the last two decades, marriage specialists have researched the ingredients of a happy marriage. As a result, we know more about building a successful marriage today than ever before.</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;">Family Problem</span>
                                    <a><img src="Default/images/family problems.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Family Problem</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details">Vedic astrology is very effective science to predict human being's destiny.It plays a vital role to study and understand human fortune and its problem and provides most effectual remedial solutions.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;"> Intercast Marriage</span>
                                    <a><img src="Default/images/Intercast_marriage.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Intercast Marriage</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details">
                                        Marriage is the approved social pattern whereby two to more persons establish a family.
                                        It involves not only the right to conceive and rear children, but also a host of other obligation and privileges affecting a good many people.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;">Relation Problem</span>
                                    <a><img src="Default/images/Relationship problem.png" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Relationship Problem</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details">Many people think love relationship problems are difficult to solve because schools don't teach you how to solve them, and different problems require a different set of solution.</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;">Business Problem</span>
                                    <a><img src="Default/images/business problem.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Business Problem</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details"> Nowadays, people are very skeptical of any kind of money making scheme, "There's no such thing as getting rich quick", "You have to work for it like everybody else, or win the lottery."</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;">Child Problem</span>
                                    <a><img src="Default/images/child problem.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Child Problem</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details"> Bedwetting is something that many children experience. Although it can be frustrating for the parent, especially when it comes time to do the laundry, bedwetting is quite common and most children will eventually outgrow it. </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;">Court Case Problem</span>
                                    <a><img src="Default/images/court case.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Court Case Problem</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details"> Do you need mantra to win court case? Need mantra to get success in court? Sadly, those who are facing such problems never come out of it that easily. The court case is more like a trap which is filed by someone to give you pain and harassment.	</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ast_blog_box">
                                <div class="ast_blog_img">
                                    <span class="ast_date_tag" style="color:white!important;"> Love Issue</span>
                                    <a><img src="Default/images/Love issue.jpg" class="fix-height-width" alt="Blog" title="Blog"></a>
                                </div>
                                <div class="ast_blog_info">
                                    <ul class="ast_blog_info_text">
                                        <li><a class="bold"><i class="fa fa-comments-o" aria-hidden="true"></i> Love Issue</a></li>
                                    </ul>
                                    <p class="ast_blog_info_details"> A lot of people pay attention to astrology predictions. whether it is western, Chinese, vedic or any other branch, astrology is considered a significant part of many people's lives. As an expert in Chinese astrology, I tried to examine how people react to certain predictions (good or bad).</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--WeDo End-->
    <!--Overview wrapper start -->
    <!--<div class="ast_overview_wrapper ast_toppadder100 ast_bottompadder100">
        <div class="ast_img_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="ast_testimonials_slider">
                        <div class="owl-carousel owl-theme">
                            <div class="item ast_overview_info">
                                <h1><span>Relationship</span> Problem</h1>
                                <p>Many people think love relationship problems are difficult to solve because schools don't teach you how to solve them, and different problems require a different set of solution.</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1><span>Family</span> Problem</h1>
                                <p>Vedic astrology is very effective science to predict human being's destiny. It plays a vital role to study and understand human fortune and its problem and provides most effectual remedial solutions. Vedic astrology was primarily based on constellation ( Nakshatra ) system of prediction but eventually adapted to house system also. House system consists of 12 Bhavas or houses that explain each and every aspects of your life. </p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Business Problem</h1>
                                <p>Well, most people want to escape the rat race. Everyone wants financial freedom and contentment. Most people don't want to get up in the morning and go to work day after day in a boring job that makes someone else rich. There must be something else, ...</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Health Problem</h1>
                                <p></p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Career Problem Solution</h1>
                                <p></p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Child Problem</h1>
                                <p>Bedwetting is something that many children experience. Although it can be frustrating for the parent, especially when it comes time to do the laundry, bedwetting is quite common and most children will eventually outgrow it. However, there are some child bedwetting solutions you can try if you don't want to wait for that to happen.</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Love Issue</h1>
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Career Problem Solution</h1>
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Love marriage Specialist</h1>
                                <p>Over the last two decades, marriage specialists have researched the ingredients of a happy marriage. As a result, we know more about building a successful marriage today than ever before.</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Husband Wife Dispute</h1>
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Get Your Love Back</h1>
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                            <div class="item ast_overview_info">
                                <h1>Court Case Problem</h1>
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>-->
    <!-- Overview wrapper end -->
    <!--Content Us Start-->
    <div class="ast_contact_wrapper ast_toppadder70 ast_bottompadder50" id="ContactUs">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1 col-xs-offset-0">
                    <div class="ast_heading">
                        <h1>get in <span>touch</span></h1>
                        <img src="Default/images/line.png" />
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="ast_contact_info">
                        <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                        <h4>phone</h4>
                        <p><a href="tel:+917434804490">+91 74348 04490</a></p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="ast_contact_info">
                        <span><i class="fa fa-envelope-open-o" aria-hidden="true"></i></span>
                        <h4>email</h4>
                        <p><a href="#">info@astroserviceconsultancy.com</a></p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="ast_contact_info">
                        <span><i class="fa fa-whatsapp" aria-hidden="true"></i></span>
                        <h4>whatsapp</h4>
                        <p><a href="https://api.whatsapp.com/send?phone=+917434804490&text=testing">+91 74348 04490</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Content Us End-->
    <!--Content Us Start-->
    <div class="ast_mapnform_wrapper ast_toppadder70" style="padding-bottom:80px">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1 col-xs-offset-0">
                    <div class="ast_heading">
                        <h1>find & message <span>here</span></h1>
                        <img src="Default/images/line.png" />
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-2 col-sm-offset-2 col-xs-offset-0">
            <div class="ast_contact_form_custom">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                            if(isset($_REQUEST['sub']))
                            {
                            require("class.phpmailer.php"); // path to the PHPMailer class
                             require("class.smtp.php");
                            $mail = new PHPMailer(); // create a new object
                            //$mail->IsSMTP(); // enable SMTP
                            $mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
                            $mail->SMTPAuth = true; // authentication enabled
                            $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
                            $mail->Host = "smtp.gmail.com";
                            $mail->Port = 465; // or 587
                            $mail->IsHTML(true);
                            $mail->Username = "150540107093@darshan.ac.in";
                            $mail->Password = "@ShaH-3134";
                            $mail->SetFrom("150540107093@darshan.ac.in");
                            $name = $_POST['name'];
                            $mail->Subject = Contact Us | Astro Service Consultancy Query;
                            $message = $_POST['message'];
                            $mailFrom = $_POST['email'];
                            $Subj = $_POST['subject'];
                            $mail->Body = "<b>* Name :</b>".$name<br/>."<b>* Subject Name :</b>".$Subj<br/>."<b>* Email :</b>".$mailFrom<br/>."<b>* Message :</b>".$message;
                            $mail->AddAddress("shahbhavyam@gmail.com");
                             if(!$mail->Send())
                                {
                                echo "Mailer Error: " . $mail->ErrorInfo;
                                }
                                else
                                {
                                echo "<p style="color:green;font-weight:700;text-align:center;"><i class="fa fa-check"></i> Message has been sent successfully</p>";
                                }
                            }
                        ?>
                    </div>
                </div>
                <form method="post">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label>Name</label>
                        <input type="text" name="name" class="require" placeholder="Enter Name">
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label>Email</label>
                        <input type="text" name="email" class="require" data-valid="email" placeholder="Enter Your Email" data-error="Email should be valid.">
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label>Subject</label>
                        <input type="text" name="subject" class="require" placeholder="Enter Subject">
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label>Message</label>
                        <textarea rows="5" name="message" class="require" placeholder="Enter Your Message"></textarea>
                    </div>
                    <div class="response"></div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <button class="ast_btn pull-right submitForm" type="submit" name="sub" form-type="contact">send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--Content Us End-->
    <!-- Footer wrapper start-->
    <div class="ast_footer_wrapper ast_toppadder70 ast_bottompadder20" ">
        <div class="container">
            <div class="ast_copyright_wrapper_custom">
                <div class="row ">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="padding-top:20px;">
                        <h4>&copy; Copyright 2018, All Rights Reserved, <a href="#">astroserviceconsultancy.com</a></h4>
                    </div>
                    <div class="col-md-2"></div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="padding-top:20px;">
                        <h4 style="text-align:right">Developed & Maintained By <a href="#">BHAVYA SHAH</a></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer wrapper End-->
    <!--Main js file Style-->
    <script type="text/javascript" src="Default/js/jquery.js"></script>
    <script type="text/javascript" src="Default/js/bootstrap.js"></script>
    <script type="text/javascript" src="Default/js/jquery.magnific-popup.js"></script>
    <script type="text/javascript" src="Default/js/owl.carousel.js"></script>
    <script type="text/javascript" src="Default/js/jquery.countTo.js"></script>
    <script type="text/javascript" src="Default/js/jquery.appear.js"></script>
    <script type="text/javascript" src="Default/js/custom.js"></script>
    <!--<script src="https://code.jquery.com/jquery-3.2.0.min.js"></script>-->
    <script src="Default/js/text-animation.js"></script>
    <!--<script src="Default/js/target.js"></script>-->
    <script>

        jQuery('.navigation a').on('click', function (event) {
            var target = jQuery(this);
            var element = target.attr('href');
            var scrollLink = $('.scroll');
            jQuery('.navigation a').removeClass('active')
            target.addClass('active');

            jQuery("body, html").animate({
                scrollTop: jQuery(element).offset().top - 95
            }, 1800);
            $(document).on("scroll", onScroll);
        });

        jQuery('.ast_bannertext_wrapper a').on('click', function (event) {
            var target = jQuery(this);
            var element = target.attr('href');
            var scrollLink = $('.scroll');

            jQuery("body, html").animate({
                scrollTop: jQuery(element).offset().top - 95
            }, 1800);
            $(document).on("scroll", onScroll);
        });

        //$(window).scroll(function () {
        //    var scrollPos = $(document).scrollTop();
        //    $('#menu-center a').each(function () {
        //        var currLink = $(this);
        //        var refElement = $(currLink.attr("href"));
        //        if (refElement.position().top - 140 <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
        //            $('#menu-center li a').removeClass("active");
        //            currLink.addClass("active");
        //        }
        //        else {
        //            currLink.removeClass("active");
        //        }
        //    });
        //}).scroll();



        anime.timeline({ loop: true })
 .add({
     targets: '.ml16 .word',
     scale: [14, 1],
     opacity: [0, 1],
     easing: "easeOutCirc",
     duration: 800,
     delay: function (el, i) {
         return 800 * i;
     }
 }).add({
     targets: '.ml16',
     opacity: 0,
     duration: 1000,
     easing: "easeOutExpo",
     delay: 1000
 });

        // Wrap every letter in a span
        $('.ml12').each(function () {
            $(this).html($(this).text().replace(/([^\x00-\x80]|\w)/g, "<span class='letter'>$&</span>"));
        });

        anime.timeline({ loop: true })
          .add({
              targets: '.ml12 .letter',
              translateX: [40, 0],
              translateZ: 0,
              opacity: [0, 1],
              easing: "easeOutExpo",
              duration: 1500,
              delay: function (el, i) {
                  return 500 + 30 * i;
              }
          }).add({
              targets: '.ml12 .letter',
              translateX: [0, -30],
              opacity: [1, 0],
              easing: "easeInExpo",
              duration: 1000,
              delay: function (el, i) {
                  return 100 + 30 * i;
              }
          });
    </script>
    <!--Main js file End-->
</body>
<!-- Mirrored from kamleshyadav.com/html/astrology/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Aug 2018 06:25:10 GMT -->
</html>